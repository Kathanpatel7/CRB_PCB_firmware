#ifndef TESTS_H
#define TESTS_H

#include "main.h"
#include "can.h"
#include "timer.h"
#include "uart.h"

// Define the width and length for the zigzag pattern
#define WIDTH 70
#define LENGTH 165

// Define servo positions
#define SERVO1_ACTUATE_POSITION 80
#define SERVO1_RETRACT_POSITION 0
#define SERVO2_ACTUATE_POSITION 0
#define SERVO2_RETRACT_POSITION 65

// Function prototypes
void screen_test(void);
void camera_test(void);
void speaker_test(void);
void zigzag_pattern(int width_X, int length_Y, int num_steps);
//void moveToCoordinates(int x, int y);
void readCANFeedback(void);
void setServoPosition(TIM_HandleTypeDef *htim, uint32_t channel, uint16_t position);
void delay_ms(uint32_t ms);

#endif // TESTS_H
