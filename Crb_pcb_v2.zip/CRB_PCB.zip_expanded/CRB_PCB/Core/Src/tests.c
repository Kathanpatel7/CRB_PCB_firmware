#include "tests.h"
#include "main.h"
#include "can.h"
#include "timer.h"
#include "uart.h"
#include "functions.h"
// Define the width and length for the zigzag pattern
#define WIDTH 70
#define LENGTH 165
int start_X = -93;
int start_Y = 210;
// Define servo positions
#define SERVO1_ACTUATE_POSITION 80
#define SERVO1_RETRACT_POSITION 0
#define SERVO2_ACTUATE_POSITION 0
#define SERVO2_RETRACT_POSITION 65

// Function prototypes
void moveToCoordinates(float x, float y);
void readCANFeedback(void);
void setServoPosition(TIM_HandleTypeDef *htim, uint32_t channel, uint16_t position);
void delay_ms(uint32_t ms);

void screen_test() {
    // Initialize the starting positions
    int width = WIDTH;
    int length = LENGTH;

    // Move to initial coordinates
    moveToCoordinates(0, 210);
    processCANMessage();

    // Start the zigzag pattern
    zigzag_pattern(width, length, 23);

    // Move back to original positions after completing the test
    moveToCoordinates(0, 40);
    moveToCoordinates(0, 10);
}

void speaker_test() {
    // Initialize the starting positions
	moveToCoordinates(start_X + (WIDTH/ 2) - 10, 210 - LENGTH);
	HAL_Delay(3000);
	moveToCoordinates(start_X + (WIDTH/ 2) - 10, 210);
	HAL_Delay(2000);
    // Move back to original positions after completing the test
    moveToCoordinates(0, 40);
    moveToCoordinates(0, 10);

}
void camera_test() {
    // Initialize the starting positions
	sendAbsoluteAxisCommand(0x004, 2000, 240, -54667);
	HAL_Delay(4000);
	sendAbsoluteAxisCommand(0x004, 2000, 240, 0);
	HAL_Delay(1000);


}


void zigzag_pattern(int width_X, int length_Y, int num_steps) {
    // Define the starting and transitional positions
    int start_X = -93;
    int start_Y = 210;
    int stepsize = length_Y / num_steps;

    // Move to initial position and actuate servos
    moveToCoordinates(start_X + (width_X / 2) - 10, 210);
    setServoPosition(&htim2, TIM_CHANNEL_1, SERVO1_ACTUATE_POSITION);
    setServoPosition(&htim2, TIM_CHANNEL_2, SERVO2_ACTUATE_POSITION);


    delay_ms(500);

    // Move to next position and retract servos
    moveToCoordinates(start_X + (width_X / 2) - 10, 210 - length_Y);
    setServoPosition(&htim2, TIM_CHANNEL_1, SERVO1_RETRACT_POSITION);
    setServoPosition(&htim2, TIM_CHANNEL_2, SERVO2_RETRACT_POSITION);
    delay_ms(500);

    // Begin zigzag pattern
    moveToCoordinates(start_X + width_X, start_Y);
    delay_ms(100);
    setServoPosition(&htim2, TIM_CHANNEL_1, SERVO1_ACTUATE_POSITION);
    delay_ms(100);

    for (int m = 1; m < num_steps; m += 2) {
    	processCANMessage();

        // Move across in zigzag steps
        moveToCoordinates(start_X + width_X, start_Y - (m * stepsize));
        processCANMessage();
        moveToCoordinates(start_X, start_Y - (m * stepsize));
        processCANMessage();
        moveToCoordinates(start_X, start_Y - ((m + 1) * stepsize));
        processCANMessage();
        moveToCoordinates(start_X + width_X, start_Y - ((m + 1) * stepsize));
    }

    // Retract servo after completing zigzag
    setServoPosition(&htim2, TIM_CHANNEL_1, SERVO1_RETRACT_POSITION);
}

// Helper function to set servo position
void setServoPosition(TIM_HandleTypeDef *htim, uint32_t channel, uint16_t position) {
    // Convert position to pulse width corresponding to the servo angle
    // Min pulse (1 ms) = ~5% duty cycle -> for 0 degrees
    // Max pulse (2 ms) = ~10% duty cycle -> for 180 degrees

    // Calculate pulse width for the desired position (0 - 180 degrees)
    uint32_t min_pulse = (htim->Init.Period + 1) * 5 / 100;  // 5% duty cycle for 0 degrees
    uint32_t max_pulse = (htim->Init.Period + 1) * 10 / 100; // 10% duty cycle for 180 degrees

    uint32_t pulse = min_pulse + ((max_pulse - min_pulse) * position) / 180;

    __HAL_TIM_SET_COMPARE(htim, channel, pulse);
}

// Helper function for delays (uses HAL_Delay in ms)
void delay_ms(uint32_t ms) {
    HAL_Delay(ms);
}
